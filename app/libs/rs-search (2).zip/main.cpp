#include "rs-search.h"
#include <chrono>
#include <iostream>
int main() {
  while (1) {
    std::string keyword;
    std::cin >> keyword;
    int success = 0;
    auto start = std::chrono::system_clock::now();
    auto res = search(keyword.c_str(), "./index", 20, &success);
    auto end = std::chrono::system_clock::now();

    std::cout << res;
    auto dur =
        std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << dur.count();
  }
}
